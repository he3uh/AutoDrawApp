package com.example.autodraw

import android.content.Context
import android.content.Intent
import android.graphics.RectF

/**
 * Singleton helper to manage region selection over other applications. When
 * [startSelection] is called, a transparent overlay is shown that allows
 * the user to tap and drag to define a rectangular area. Once the user
 * completes the selection, the provided callback is invoked with the
 * rectangle coordinates. The overlay is hosted in [RegionOverlayService].
 */
object RegionSelector {
    private var callback: ((RectF) -> Unit)? = null

    /**
     * Launch the region selection overlay. The given [context] is used to
     * start the service responsible for drawing the overlay. When the
     * selection is completed, [onRegionSelected] will be triggered with the
     * selected rectangle and the callback provided here will be invoked.
     */
    fun startSelection(context: Context, callback: (RectF) -> Unit) {
        this.callback = callback
        val intent = Intent(context, RegionOverlayService::class.java)
        intent.putExtra(RegionOverlayService.EXTRA_START_SELECTION, true)
        context.startService(intent)
    }

    /**
     * Called by the overlay service when the user finishes selecting a region.
     */
    internal fun onRegionSelected(rect: RectF) {
        callback?.invoke(rect)
        callback = null
    }
}