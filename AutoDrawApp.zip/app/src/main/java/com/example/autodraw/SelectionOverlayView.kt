package com.example.autodraw

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Transparent view that allows the user to define a rectangular area by
 * tapping and dragging on the screen. This view is intended to be
 * displayed as an overlay by [RegionOverlayService]. When a region has
 * been selected, the [onSelected] callback is invoked with the screen
 * coordinates. Coordinates are relative to the overlay's coordinate system.
 */
class SelectionOverlayView(context: Context, private val onSelected: (RectF) -> Unit) : View(context) {

    private var startX = 0f
    private var startY = 0f
    private var currentX = 0f
    private var currentY = 0f
    private var selecting = false
    private val paint = Paint().apply {
        color = Color.RED
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (selecting) {
            val left = minOf(startX, currentX)
            val right = maxOf(startX, currentX)
            val top = minOf(startY, currentY)
            val bottom = maxOf(startY, currentY)
            canvas.drawRect(left, top, right, bottom, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.rawX
                startY = event.rawY
                currentX = startX
                currentY = startY
                selecting = true
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (selecting) {
                    currentX = event.rawX
                    currentY = event.rawY
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (selecting) {
                    currentX = event.rawX
                    currentY = event.rawY
                    val rect = RectF(
                        minOf(startX, currentX),
                        minOf(startY, currentY),
                        maxOf(startX, currentX),
                        maxOf(startY, currentY)
                    )
                    selecting = false
                    invalidate()
                    // Notify the selected region
                    onSelected(rect)
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}