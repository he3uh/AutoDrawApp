package com.example.autodraw

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.WindowManager

/**
 * Foreground service that displays a transparent overlay view on top of all
 * other applications. The overlay allows the user to draw a rectangle by
 * tapping and dragging. Once the selection is complete, the region is
 * forwarded to [RegionSelector] and the service stops itself.
 */
class RegionOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: SelectionOverlayView? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getBooleanExtra(EXTRA_START_SELECTION, false) == true) {
            showOverlay()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        if (overlayView != null) {
            windowManager.removeView(overlayView)
            overlayView = null
        }
    }

    private fun showOverlay() {
        if (overlayView != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = SelectionOverlayView(this) { rect ->
            RegionSelector.onRegionSelected(rect)
            stopSelf()
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        )
        // Add the overlay view to the window manager
        windowManager.addView(overlayView, params)
    }

    companion object {
        const val EXTRA_START_SELECTION = "extra_start_selection"
    }
}