package com.example.autodraw

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.RectF

/**
 * Utility object for converting an input bitmap into a collection of drawing
 * paths. The generated paths approximate the dark regions of the image by
 * scanning each row and producing horizontal segments wherever pixels fall
 * below a threshold. While simplistic compared to edge-detection algorithms,
 * this approach avoids any native dependencies and performs adequately on
 * high-contrast images such as line art or simple logos.
 */
object ImageProcessing {
    /**
     * Convert a bitmap to drawing paths scaled to fit within [targetRect]. The
     * method scans each row of the bitmap and generates a [Path] for every
     * continuous run of dark pixels (as determined by [threshold]). Each
     * resulting path is scaled and translated into the coordinate space of
     * [targetRect].
     *
     * @param bitmap The source bitmap. Should be fully loaded in memory.
     * @param targetRect The rectangle within which to fit the drawing.
     * @param threshold Pixel luminance threshold (0-255); pixels darker than
     * this value are considered part of the drawing. Lower values produce
     * more aggressive filtering.
     * @return List of paths representing the drawing strokes.
     */
    fun bitmapToPaths(
        bitmap: Bitmap,
        targetRect: RectF,
        threshold: Int = 128
    ): List<Path> {
        val width = bitmap.width
        val height = bitmap.height
        val paths = mutableListOf<Path>()
        if (width == 0 || height == 0) return paths
        // Calculate scaling factors to map bitmap coordinates into targetRect
        val scaleX = targetRect.width() / width.toFloat()
        val scaleY = targetRect.height() / height.toFloat()
        for (y in 0 until height) {
            var drawing = false
            var path: Path? = null
            for (x in 0 until width) {
                val pixel = bitmap.getPixel(x, y)
                // Convert to luminance by averaging RGB components
                val luminance = ((Color.red(pixel) + Color.green(pixel) + Color.blue(pixel)) / 3)
                val dark = luminance < threshold
                if (dark) {
                    val worldX = targetRect.left + x * scaleX
                    val worldY = targetRect.top + y * scaleY
                    if (!drawing) {
                        path = Path().apply { moveTo(worldX, worldY) }
                        drawing = true
                    } else {
                        path?.lineTo(worldX, worldY)
                    }
                } else {
                    if (drawing) {
                        path?.let { paths.add(it) }
                        path = null
                        drawing = false
                    }
                }
            }
            if (drawing) {
                path?.let { paths.add(it) }
            }
        }
        return paths
    }
}