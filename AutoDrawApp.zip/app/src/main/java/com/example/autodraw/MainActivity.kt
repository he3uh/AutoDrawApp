package com.example.autodraw

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Main entry activity that guides the user through granting permissions,
 * selecting an image, choosing a region to draw, and then initiating
 * automated drawing via the accessibility service. This activity does not
 * perform the drawing itself—it delegates to [AutoDrawAccessibilityService]
 * once all prerequisites are in place.
 */
class MainActivity : AppCompatActivity() {

    private var selectedBitmap: Bitmap? = null
    private var selectedRect: android.graphics.RectF? = null

    private lateinit var pickImageLauncher: ActivityResultLauncher<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        val btnEnableAccessibility = findViewById<Button>(R.id.btnEnableAccessibility)
        btnEnableAccessibility.setOnClickListener {
            // Launch accessibility settings so the user can enable the service
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val btnRequestOverlay = findViewById<Button>(R.id.btnRequestOverlay)
        btnRequestOverlay.setOnClickListener {
            requestOverlayPermission()
        }

        val btnSelectImage = findViewById<Button>(R.id.btnSelectImage)
        btnSelectImage.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        val btnSelectRegion = findViewById<Button>(R.id.btnSelectRegion)
        btnSelectRegion.setOnClickListener {
            if (!hasOverlayPermission()) {
                Toast.makeText(this, R.string.request_overlay_permission, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            RegionSelector.startSelection(this) { rect ->
                selectedRect = rect
                tvStatus.text = "Selected region: ${rect.toShortString()}"
            }
        }

        val btnDraw = findViewById<Button>(R.id.btnDraw)
        btnDraw.setOnClickListener {
            startDrawing()
        }

        // Prepare the image picker result launcher
        pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                val bitmap = getBitmapFromUri(this, uri)
                if (bitmap != null) {
                    selectedBitmap = bitmap
                    tvStatus.text = "Image selected (${bitmap.width}x${bitmap.height})"
                } else {
                    Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /**
     * Check if the application has permission to draw over other apps.
     */
    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) true else Settings.canDrawOverlays(this)
    }

    /**
     * Request the user to grant overlay permission. On Android M and above,
     * the user must manually grant this permission via system settings.
     */
    private fun requestOverlayPermission() {
        if (hasOverlayPermission()) {
            Toast.makeText(this, "Overlay permission already granted", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        startActivity(intent)
    }

    /**
     * Start the drawing process by converting the selected image into paths
     * and delegating those paths to the accessibility service for gesture
     * playback.
     */
    private fun startDrawing() {
        val bitmap = selectedBitmap
        val rect = selectedRect
        if (bitmap == null || rect == null) {
            Toast.makeText(this, "Please select an image and region first", Toast.LENGTH_SHORT).show()
            return
        }
        // Generate the drawing paths from the bitmap scaled into the selected region
        val paths = ImageProcessing.bitmapToPaths(bitmap, rect)
        if (paths.isEmpty()) {
            Toast.makeText(this, "No drawing paths generated from image", Toast.LENGTH_SHORT).show()
            return
        }
        // Use the accessibility service instance to draw the paths sequentially
        val service = AutoDrawAccessibilityService.instance
        if (service != null) {
            service.drawPathsSequentially(paths, strokeDuration = 500L, gapMs = 50L) {
                runOnUiThread {
                    Toast.makeText(this, "Drawing complete", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Accessibility service is not enabled", Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        /**
         * Helper method to decode a URI into a Bitmap. This reads all pixels
         * into memory, so for very large images you may need to scale
         * down or decode with options.
         */
        fun getBitmapFromUri(context: Context, uri: Uri): Bitmap? {
            return try {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    BitmapFactory.decodeStream(inputStream)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
}