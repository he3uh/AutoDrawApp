package com.example.autodraw

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility service that can dispatch custom gesture sequences. It listens
 * for no specific events; it merely exposes [drawPathsSequentially] to
 * allow other components to programmatically draw onto the screen via
 * accessibility gestures.
 */
class AutoDrawAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No event handling required for drawing; service is passive
    }

    override fun onInterrupt() {
        // No-op
    }

    /**
     * Draw a single path gesture. You can adjust the [durationMs] to
     * increase or decrease the speed of the stroke. [startTimeMs] can be
     * used to schedule multiple strokes within a single gesture; however,
     * for sequential drawing you should use [drawPathsSequentially].
     */
    fun drawStroke(path: Path, durationMs: Long = 500L, startTimeMs: Long = 0L, onDone: (() -> Unit)? = null) {
        val stroke = GestureDescription.StrokeDescription(path, startTimeMs, durationMs, false)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onDone?.invoke()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                onDone?.invoke()
            }
        }, null)
    }

    /**
     * Sequentially dispatch a list of [Path] objects as separate gestures. Each
     * gesture is executed after the previous one completes, separated by
     * [gapMs] milliseconds. The [strokeDuration] parameter controls how long
     * each gesture should take. When all paths have been drawn, the
     * optional [done] callback is invoked.
     */
    fun drawPathsSequentially(
        paths: List<Path>,
        strokeDuration: Long = 500L,
        gapMs: Long = 50L,
        done: (() -> Unit)? = null
    ) {
        if (paths.isEmpty()) {
            done?.invoke()
            return
        }
        val handler = Handler(Looper.getMainLooper())
        fun next(index: Int) {
            if (index >= paths.size) {
                done?.invoke()
                return
            }
            drawStroke(paths[index], strokeDuration) {
                handler.postDelayed({ next(index + 1) }, gapMs)
            }
        }
        next(0)
    }

    companion object {
        /** Global reference to the service instance, set on connection and cleared on destroy. */
        @Volatile
        var instance: AutoDrawAccessibilityService? = null
            private set
    }
}